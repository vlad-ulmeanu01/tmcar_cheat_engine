#include "tmc_utility.h"
#include "tmc_process.h"
#include "tmc_tmcar.h"
#include "tmc_functions.h"

int main() {
  TM_CAR tmc;
  ///tmc.parse_input_file<float>("tm_values.txt", tmc.values);
  tmc.parse_input_file<DWORD>("tm_value_addresses.txt", tmc.value_addresses);

  tmc.init_keymapping();

  /// TODO fa functie care parseaza points_of_interest
  tmc.points_of_interest.push_back({std::make_tuple(321.650, 9.359, 507.773),  5000, 100, 2.0, false});
  tmc.points_of_interest.push_back({std::make_tuple(323.160, 9.359, 579.627),  7500, 100, 2.0, false});
  tmc.points_of_interest.push_back({std::make_tuple(251.292, 9.359, 607.919), 20000, 100, 5.0, false});

  PROCESS_T proc;
  proc.get_process_by_name("TrackMania United Forever");

  //teleport_car_by_ox(tmc, proc);
//  get_pos_indefinitely(tmc, proc);
  //move_car_by_ox(tmc, proc);
  //checkpoint_reach(tmc, proc);

  std::vector<TM_OTH::point_in_simulation> sim_points;

  std::this_thread::sleep_for(std::chrono::milliseconds(5000));
  depth_first_search(tmc, proc, sim_points);

  return 0;
}
