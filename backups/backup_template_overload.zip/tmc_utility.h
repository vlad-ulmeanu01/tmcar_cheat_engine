#ifndef __TMC_UTILITY_H
#define __TMC_UTILITY_H

#define _WIN32_WINNT 0x0500
#include <windows.h>

#include <iostream>
#include <fstream>
#include <cstring>
#include <cassert>
#include <typeinfo>
#include <unordered_map>
#include <chrono>
#include <thread>
#include <tuple>
#include <vector>

#define DEBUG 0

namespace TM_OTH {

  struct point_of_interest {
    std::tuple<float, float, float> pos;
    int best_before_time;  /// measured in milliseconds (UINT ingame)
    int score_upon_completion;
    float meet_radius;
    bool has_reached;
  };

  struct point_in_simulation {
    point_in_simulation () {
      run_after_this_time = 0;
      is_pressed["up"] = is_pressed["dn"] = is_pressed["le"] = is_pressed["ri"] = false;
    }
    int run_after_this_time;
    std::unordered_map<std::string, bool> is_pressed; /// accepts "up", "dn", "le", "ri"
  };

  float square (float a);

  float squared_distance (std::tuple<float, float, float> a, std::tuple<float, float, float> b);

  template<typename T>
  std::tuple<float, float, float> make_tuple_from_container (T cont, std::vector<std::string> s);
}

#endif
